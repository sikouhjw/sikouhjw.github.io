# 作者

- 电气 173 班何骏炜
- 联系邮箱：`sikouhjw@gmail.com`
- 托管网址：暂无

# 免责声明

本文档不提供保证，不包含任何类型的保证（无论是明指的还是暗喻的），包含但不限于关于本文档的适销性、特定用途的适用性和无侵权保证。在任何情况下，无论是否签订了合约、存在侵权行为还是在其他情况下，本文档作者或版权持有人不对由本文档直接或间接产生的或由使用本文档或处置本文档所产生的任何索赔、损坏或者其他责任负责。

# 设计想法

`附件5.本科毕业设计（论文）格式.doc` 中很多地方是自相矛盾的，我选择了部分规范作为标准（还自主在未规定处用自己的审美写了样式），可自行修改样式。

# 补充 word 使用方法
## 三线表

输入表格后
- 点击「表格工具」→「设计」→「表格2」（表格样式）即可得到三线表
- 点击「样式」→「表格」即可得到字体正确、间距舒服的表格

## 列表

- 无序列表：「段落」→「多级列表」→「列表样式」→「无序列表」
- 有序列表：「段落」→「多级列表」→「列表样式」→「有序列表」
- 若点击后默认列表级别不正确，可以点击「编号」→「更改列表级别」

## 参考文献

- https://zhuanlan.zhihu.com/p/136685744
- https://jingyan.baidu.com/article/cbcede074db06d02f40b4db4.html
- 中国知网等网站导出条目

## 数学公式

- https://www.unicode.org/notes/tn28/UTN28-PlainTextMath-v3.1.pdf
- https://blog.csdn.net/weixin_42950180/article/details/104501920
- 如果出现显示不全的情况，请使用「公式」样式

## 脚注

- https://product.pconline.com.cn/itbk/software/bgrjjc/1704/9041539.html

## 合并 word 文档

- https://docs.microsoft.com/zh-cn/office/troubleshoot/word/merge-word-documents


# 未完成（能力不足 / 懒）

- 图片子标题的样式
- 小论文的样式
- 跨平台支持
- 数学公式的交叉引用（可自行用[域代码](https://zhuanlan.zhihu.com/p/139398112)实现）
- 目录中 chapter 后添加两字符间距